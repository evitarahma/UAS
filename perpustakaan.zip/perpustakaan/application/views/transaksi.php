<div class="container">
<form action="welcome/tambahrekordtransaksi" method="post">
  <div class="form-group">
    <label for="kode pustaka">Kode Pustaka:</label>
  <textarea class="form-control" rows="5" id="kode pustaka" name="kode pustaka"></textarea>
  </div>
  <div class="form-group">
    <label for="nomor anggota">Nomor Anggota:</label>
  <textarea class="form-control" rows="5" id="nomor anggota" name="nomor anggota"></textarea>
  </div>
  <div class="form-group">
    <label for="kode pustakawan pinjam">Kode Pustakawan Pinjam:</label>
   <textarea class="form-control" rows="5" id="kode pustakawan pinjam" name="kode pustakawan pinjam"></textarea>
  </div>
  <div class="form-group">
    <label for="tanggal pinjam">Tanggal Pinjam:</label>
  <input type="datetime-local" class="form-control" id="tanggal pinjam" name="tanggal pinjam"></textarea>
  </div>
  <div class="form-group">
    <label for="kode pustakawan kembali">Kode Pustakawan Kembali:</label>
   <textarea class="form-control" rows="5" id="kode pustakawan kembali" name="kode pustakawan kembali"></textarea>
  </div>
  <div class="form-group">
    <label for="tanggal kembali">Tanggal Kembali:</label>
  <input type="datetime-local" class="form-control" id="tanggal kembali" name="tanggal kembali"></textarea>
  </div>
  <button type="submit" class="btn btn-primary" name="bSimpan">Submit</button>
</form>
</div>