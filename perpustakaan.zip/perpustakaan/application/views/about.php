<div class="container">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="#">
    <img src="<?= base_url();?>/img/vita.png" alt="logo" style="width:400px;">
<form action="welcome/tambahrekordabout" method="post">
  <div class="form-group">
    <label for="nama pembuat">Nama Pembuat:</label>
  <textarea class="form-control" rows="5" id="nama pembuat" name="nama pembuat">EVITA RAHMADONA</textarea>
  </div>
  <div class="form-group">
    <label for="npm pembuat">NPM Pembuat:</label>
  <textarea class="form-control" rows="5" id="npm pembuat" name="npm pembuat">1955201157</textarea>
  </div>
 </form>
</div>