<div class="container">
  <h3>SELAMAT DATANG</h3>
  <p>Selamat Datang di Aplikasi Perpustakaan Sekolah Menengah Atas Insan Cendekia.</p>
</div>

</body>
</html>