<div class="container">
<form action="welcome/tambahrekordpustaka" method="post">
  <div class="form-group">
    <label for="kode pustaka">Kode Pustaka:</label>
  <textarea class="form-control" rows="5" id="kode pustaka" name="kode pustaka"></textarea>
  </div>
  <div class="form-group">
    <label for="judul pustaka">Judul Pustaka:</label>
  <textarea class="form-control" rows="5" id="judul pustaka" name="judul pustaka"></textarea>
  </div>
  <div class="form-group">
    <label for="pengarang">Pengarang:</label>
   <textarea class="form-control" rows="5" id="pengarang" name="pengarang"></textarea>
  </div>
  <div class="form-group">
    <label for="penerbit">Penerbit:</label>
  <textarea class="form-control" rows="5" id="penerbit" name="penerbit"></textarea>
  </div>
    <div class="form-group">
  <label for="tahun terbit">Tahun Terbit:</label>
  <textarea class="form-control" rows="5" id="tahun terbit" name="tahun terbit"></textarea>
  </div>
  <button type="submit" class="btn btn-primary" name="bSimpan">Submit</button>
</form>
</div>