<div class="container">
<form action="welcome/tambahrekordpustakawan" method="post">
  <div class="form-group">
    <label for="kode pustakawan">Kode Pustakawan:</label>
  <textarea class="form-control" rows="5" id="kode pustakawan" name="kode pustakawan"></textarea>
  </div>
  <div class="form-group">
  <label for="nama pustakawan">Nama Pustakawan:</label>
    <textarea class="form-control" rows="5" id="nama pustakawan" name="nama pustakawan"></textarea>
  </div>
  <div class="form-group">
    <div class="form-group">
  <label for="password">Password:</label>
  <textarea class="form-control" rows="5" id="password" name="password"></textarea>
  </div>
  <div class="form-group">
  <label for="nomor telepon">Nomor Telepon:</label>
  <textarea class="form-control" rows="5" id="nomor telepon" name="nomor telepon"></textarea>
  </div>
  <button type="submit" class="btn btn-primary" name="bSimpan">Submit</button>
</form>
</div>